var i: number;

for (i = 8; i <= 120; i+=12){
    console.log(i);
}

console.log("Fim!");