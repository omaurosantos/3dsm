let contador: number = 1;  
let soma: number = 0;      

while (contador <= 10) {   
    soma += contador;     
    contador++;            
}

console.log("A soma dos inteiros de 1 a 10 é:", soma);
