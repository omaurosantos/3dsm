for (var cont: number = 1; cont <= 11; cont++){
    console.log("Número:", +cont);
}

console.log("Fim!");