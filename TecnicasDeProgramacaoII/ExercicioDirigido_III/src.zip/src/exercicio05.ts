var i: number;

for (i = 20; i > -2; i-=2){
    console.log(i);
}

console.log("Fim!");