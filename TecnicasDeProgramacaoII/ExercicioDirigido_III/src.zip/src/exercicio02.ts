var i: number;

for (i = 5; i <= 11; i++){
    console.log(i);
}

console.log("Fim!");