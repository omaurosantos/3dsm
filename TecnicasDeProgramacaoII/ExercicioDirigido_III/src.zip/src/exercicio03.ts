var i: number;

for (i = 4; i <= 23; i++){
    console.log(i);
}

console.log("Fim!");