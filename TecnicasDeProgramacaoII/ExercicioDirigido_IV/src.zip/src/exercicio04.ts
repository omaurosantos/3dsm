var nomes: string[] = [
  "Mauro",
  "Mikael",
  "Maik",
  "Mário",
  "Marcílio"
];
for (var i = 0; i < 5; i++) {
  console.log("Conheço alguém chamado:", nomes[i]);
}

export{}