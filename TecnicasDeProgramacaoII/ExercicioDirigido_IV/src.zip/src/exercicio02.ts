var vetor: number[] = [];
for (var x:number = 1; x < 100; x++){
    vetor [x] = Math.floor(Math.random() * 100) + 1;
}

console.log(vetor[3]);