var cidades: string[] = [
  "São Paulo",
  "Rio de Janeiro",
  "Salvador",
  "Belo Horizonte",
  "Porto Alegre",
  "Caraguatatuba",
  "Campos do Jordão",
  "Paraty",
];
for (var i = 0; i < 8; i++) {
  console.log("Gostaria de visitar a cidade:", cidades[i]);
}
